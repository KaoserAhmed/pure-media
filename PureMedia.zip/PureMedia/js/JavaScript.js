$(document).ready(function(){
	$(window).on("scroll resize",function(){
		var cont= $('#kaoser');
		if (pageYOffset >=1 || window.innerWidth<=767) {
		  	cont.css("background-color" ,"rgba(18,21,27,1)");
		  	cont.css("transition" ,"background-color ease-in 1s");
		}else if(pageYOffset==0){
		  	cont.css("background-color" ,"rgba(0,0,0,.33)");
		  	cont.css("transition" ,"background-color ease-in 1s");
		}
	});
});


$(document).ready(function(){
	setInterval('captionChanger()',4000);
});

var i=3;
function captionChanger(){
	var caption = document.getElementById('carousel');
	if (i==5) {
		caption.childNodes[i].className="active";
		caption.childNodes[3].className="deactive";
		
		i=1;
	}else if(i==1){
		caption.childNodes[i].className="active";
		caption.childNodes[5].className="deactive";
		
		i=i+2;
	}else if(i==3){
		caption.childNodes[i].className="active";
		caption.childNodes[1].className="deactive";
		
		i=i+2;

	}
}



